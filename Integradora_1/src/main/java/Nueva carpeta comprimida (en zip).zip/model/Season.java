package model;

public enum Season {
    WINTER, SPRING, SUMMER, AUTUMN, OTHER;
}
