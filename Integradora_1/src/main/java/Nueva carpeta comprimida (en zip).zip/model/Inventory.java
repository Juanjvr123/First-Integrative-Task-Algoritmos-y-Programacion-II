package model;

import structures.LinkedList;

public class Inventory {
    private LinkedList<Plantation> readyPlantations;
}
