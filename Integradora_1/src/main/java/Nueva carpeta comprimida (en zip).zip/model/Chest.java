package model;

import structures.LinkedList;
import structures.Node;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Chest {
    private LinkedList<Stack> stacks; // Lista de stacks en el cofre
    public static final int MAX_STACKS = 50; // Capacidad máxima del cofre
    private String classificationType;  // Tipo de ítem que puede almacenar
    private boolean isClassified;
    private String name;

    public Chest(String name) {
        this.stacks = new LinkedList<>();
        this.classificationType = "All"; // Por defecto, acepta todos los tipos
        this.isClassified = false;
        this.name = name;
    }

    public boolean addPlantation(Plantation plantation) {
        // Verificar la clasificación del cofre
        if (!classificationType.equals("All") && !classificationType.equalsIgnoreCase(plantation.getName())) {
            System.out.println("Este cofre solo acepta: " + classificationType);
            return false;
        }

        // Buscar un stack existente de la misma plantación
        Node<Stack> current = stacks.getHead();
        while (current != null) {
            Stack stack = current.getData();

            // Si hay un stack de la misma plantación y no está lleno, preguntar si quiere stackear
            if (stack.getPlantation().getName().equalsIgnoreCase(plantation.getName())) {
                if (!stack.isFull()) {
                    boolean stackear = askUserToStack(plantation.getName());

                    if (stackear) {
                        return stack.addPlantation(plantation);
                    }
                } else {
                    System.out.println("El stack está lleno. No se puede agregar más al stack.");
                }
            }
            current = current.getNextNode();
        }

        // Si no encontró un stack o el usuario decidió no stackear, intentar crear un nuevo stack
        if (stacks.size() < MAX_STACKS) {
            Stack newStack = new Stack(plantation);
            stacks.add(newStack);
            System.out.println("Nueva plantación añadida en un nuevo stack.");
            return true;
        } else {
            System.out.println("Cofre lleno. No se puede agregar más stacks.");
            return false;
        }
    }


    private boolean askUserToStack(String plantationName) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ya existe un stack de " + plantationName + ". ¿Desea apilar esta plantación en el stack existente?");
        System.out.println("[1] Sí");
        System.out.println("[2] No, crear un nuevo stack");

        int option = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        return option == 1; // Retorna true si elige apilar
    }

    private List<Stack> stacks() {
        return (List<Stack>) stacks;
    }

    public void organizeByName() {
        List<Stack> stackList = stacks();
        stackList.sort(new PlantationNameComparator());
        stacks = new LinkedList<>();
    }


    public void organizeBySeason() {
        List<Stack> stackList = stacks();
        stackList.sort(new PlantationSeasonComparator());
        stacks = new LinkedList<>();
    }

    public void organizeByGrowthDays() {
        List<Stack> stackList = stacks();
        stackList.sort(new PlantationGrowthDaysComparator());
        stacks = new LinkedList<>();
    }

    public String getClassificationType() {
        return classificationType;
    }

    public void setClassificationType(String classificationType) {
        this.classificationType = classificationType;
    }

    public boolean isFull() {
        return stacks.size() >= MAX_STACKS;
    }

    public String listPlantations() {
        return stacks.printList();
    }



    public boolean isClassified() {
        return isClassified;
    }

    public LinkedList<Stack> getStacks() {
        return stacks;
    }

    public void setClassified(boolean isClassified) {
        this.isClassified = isClassified;
    }

    public int getMaxStacks() {
        return MAX_STACKS;
    }

    public void addStack(Stack stack) {
        this.stacks.add(stack);
    }


    @Override
    public String toString() {
        return "Chest{" +
                "name='" + name + '\'' +
                ", classificationType='" + classificationType + '\'' +
                ", isClassified=" + isClassified +
                '}';
    }

}
