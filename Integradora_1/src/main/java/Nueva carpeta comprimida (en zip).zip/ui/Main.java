package ui;

import java.util.Scanner;
import controller.Controller;
import exceptions.IncorrectSeasonException;
import exceptions.InexistentPlantationException;
import exceptions.InventoryFullException;
import exceptions.PlantWrongToChestClassificationException;
import exceptions.InexistentChestException;
import exceptions.InventoryEmptyException;
import exceptions.ChestFullException;
import model.Plantation;
import model.Season;
import model.Chest;

public class Main {

    // Atributos
    private Scanner reader;

    // Relaciones
    private Controller controller;

    public static void main(String[] args) throws InexistentChestException {
        Main exe = new Main();
        exe.menu();
    }

    public Main() {
        reader = new Scanner(System.in);
        controller = new Controller();
    }

    public void menu() throws InexistentChestException {
        boolean flag = true;

        while (flag) {
            System.out.println("Welcome to Stardew Valley");
            System.out.println("What would you like to do?");
            System.out.println("[1] Plant");
            System.out.println("[2] Harvest Plantation");
            System.out.println("[3] Craft a chest");
            System.out.println("[4] Save an item from your inventory to a chest");
            System.out.println("[5] Take an item from a chest to your inventory");
            System.out.println("[6] Organize chest items");
            System.out.println("[7] Classify chest");
            System.out.println("[8] Add wood to inventory");
            System.out.println("[9] Exit Game");

            int option = reader.nextInt();
            reader.nextLine(); // Clear buffer

            switch (option) {
                case 1:
                    createPlantation();
                    break;
                case 2:
                    harvestPlantation();
                    break;
                case 3:
                    createChest();
                    break;
                case 4:
                    savePlantationInChest();
                    break;
                case 5:
                    takeItemFromChest();
                    break;
                case 6:
                    organizeChest();
                    break;
                case 7:
                    classifyChest();
                    break;
                case 8:
                    addWoodToInventory();
                    break;
                case 9:
                    flag = false;
                    System.out.println("Thank you for playing Stardew Valley!");
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
                    break;
            }
        }
    }

    public void createPlantation() {
        System.out.println("What Plantation do you want to create?");
        System.out.println(controller.listAvaliblePlantations());
        System.out.println("The actual season is " + controller.showCurrentSeason());
        String plantationName = reader.nextLine();
        try {
            if (controller.createPlantationByName(plantationName)) {
                System.out.println("Plantation created successfully.");
            }
        } catch (IncorrectSeasonException e) {
            System.out.println(e.getMessage());
        }
    }

    public void harvestPlantation() {
        System.out.println("Available plantations to harvest:");
        System.out.println(controller.listCropFieldReadyPlantations());

        System.out.println("Enter the name of the plantation you want to harvest:");
        String plantationName = reader.nextLine();

        try {
            if (controller.movePlantationFromCropFieldToInventory(plantationName)) {
                System.out.println("Plantation successfully harvested and stored in your inventory.");
            } else {
                System.out.println("The specified plantation could not be found in the crop field.");
            }
        } catch (InventoryFullException e) {
            System.out.println(e.getMessage());
        }
    }

    public void addWoodToInventory() {
        controller.addWood(50);
    }

    public void createChest() throws InexistentChestException {
        System.out.println("Type the new chest name:");
        String chestName = reader.nextLine();

        // Preguntar si desea clasificar el cofre
        System.out.println("Do you want to classify the chest? [1] Yes, [2] No");
        int classifyOption = reader.nextInt();
        reader.nextLine(); // Limpiar buffer

        boolean classifyChest = false;
        String itemType = null;

        if (classifyOption == 1) {

            classifyChest();
            classifyChest = true;  // Marcar como clasificado
        }


        boolean created = controller.createChest(chestName, itemType);
        if (created) {
            System.out.println("Chest '" + chestName + "' created successfully.");
            if (classifyChest) {
                System.out.println("Chest classified successfully.");
            }
        } else {
            System.out.println("Failed to create chest due to insufficient resources.");
        }
    }


    public void savePlantationInChest() {
        System.out.println("Enter the chest name where you are going to save an item:");
        System.out.println(controller.listChests());
        String chestName = reader.nextLine();

        Chest chest = controller.searchChestByName(chestName);
        if (chest != null) {
            System.out.println("Enter the name of the plantation to save:");
            System.out.println(controller.listInventory());
            String plantationName = reader.nextLine();

            try {
                Plantation plantationToMove = controller.getPlantationFromInventory(plantationName);

                if (controller.movePlantationToChest(chest, plantationToMove)) {
                    System.out.println("Plantation successfully added to the chest.");
                }
            } catch (ChestFullException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IncorrectSeasonException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (InexistentPlantationException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } else {
            System.out.println("Chest not found.");
        }
    }


    public void takeItemFromChest() {
        System.out.println("Enter the chest name where you are going to take an item:");
        System.out.println(controller.listChests());
        String chestName = reader.nextLine();
        Chest chest = controller.searchChestByName(chestName);

        if (chest != null) {
            if (controller.validateOrganizedChest(chest)) {
                System.out.println("Do you want to search the plantation in the chest by its name? [1]Yes, [2]No");
                int option = reader.nextInt(); // Leer la opción del usuario
                reader.nextLine(); // Consumir la nueva línea

                switch (option) {
                    case 1:
                        // Buscar plantaciones por nombre parcial
                        System.out.println("Type the initial string of the plantation name to search:");
                        String partialName = reader.nextLine();
                        System.out.println("Matching plantations in the chest:");
                        System.out.println(controller.listChestPlantationsByPartialName(chest, partialName));

                        System.out.println("Type the full plantation name to take out from the chest:");
                        String fullName = reader.nextLine();
                        try {
                            controller.moveItemFromChestToInventory(chest, fullName);
                            System.out.println("Plantation successfully moved to inventory.");
                        } catch (InventoryFullException e) {
                            System.out.println("Cannot move plantation: " + e.getMessage());
                        } catch (PlantWrongToChestClassificationException | InexistentPlantationException e) {
                            System.out.println("Cannot move plantation: " + e.getMessage());
                        }
                        break;

                    case 2:
                        // Seleccionar plantación directamente por nombre completo
                        System.out.println("Type the plantation name to take out from the chest:");
                        System.out.println(controller.listChestPlantations(chest));
                        String plantationName = reader.nextLine();
                        try {
                            controller.moveItemFromChestToInventory(chest, plantationName);
                            System.out.println("Plantation successfully moved to inventory.");
                        } catch (InventoryFullException e) {
                            System.out.println("Cannot move plantation: " + e.getMessage());
                        } catch (PlantWrongToChestClassificationException e) {
                            System.out.println("Cannot move plantation: " + e.getMessage());
                        } catch (InexistentPlantationException e) {
                            throw new RuntimeException(e);
                        }
                        break;

                    default:
                        System.out.println("Invalid option, please try again.");
                        break;
                }
            }
        } else {
            System.out.println("Chest not found. Please try again.");
        }
    }
    public void organizeChests() {
        System.out.println("Choose how you want to organize the chests:");
        System.out.println("[1] By Name");
        System.out.println("[2] By Season");
        System.out.println("[3] By Growth Days");
        int option = reader.nextInt();
        reader.nextLine();  // Limpiar el buffer

        boolean organized = false;

        switch (option) {
            case 1:
                organized = controller.organizeChestByName();
                if (organized) {
                    System.out.println("All chests have been organized by name.");
                } else {
                    System.out.println("No chests to organize.");
                }
                break;

            case 2:
                organized = controller.organizeChestBySeason();
                if (organized) {
                    System.out.println("All chests have been organized by season.");
                } else {
                    System.out.println("No chests to organize.");
                }
                break;

            case 3:
                organized = controller.organizeChestByGrowthDays();
                if (organized) {
                    System.out.println("All chests have been organized by growth days.");
                } else {
                    System.out.println("No chests to organize.");
                }
                break;

            default:
                System.out.println("Invalid option. Please try again.");
                break;
        }
    }


    public void classifyChest() throws InexistentChestException {
        System.out.println("Enter the chest name to classify:");
        String chestName = reader.nextLine();
        Chest chest = controller.searchChestByName(chestName);

        if (chest != null) {
            int option = 0;
            Season selectedSeason = null;


            while (option < 1 || option > 4) {
                System.out.println("Choose the type of item to classify in the chest:");
                System.out.println("[1] SPRING");
                System.out.println("[2] SUMMER");
                System.out.println("[3] AUTUMN");
                System.out.println("[4] WINTER");
                option = reader.nextInt();
                reader.nextLine();

                switch (option) {
                    case 1:
                        selectedSeason = Season.SPRING;
                        break;
                    case 2:
                        selectedSeason = Season.SUMMER;
                        break;
                    case 3:
                        selectedSeason = Season.AUTUMN;
                        break;
                    case 4:
                        selectedSeason = Season.WINTER;
                        break;
                    default:
                        System.out.println("Invalid option. Please choose a valid season.");
                }
            }

            // Clasificar el cofre con la temporada seleccionada
            controller.classifyChest(chest, selectedSeason);
            System.out.println("Chest classified as " + selectedSeason + ".");
        } else {
            System.out.println("Chest not found.");
        }
    }

    public void organizeChest(){

        System.out.println("Choose how you want to organize the chest:");
        System.out.println("[1] By Name");
        System.out.println("[2] By Season");
        System.out.println("[3] By Growth Days");
        int option = reader.nextInt();
        reader.nextLine();
        boolean organized = false;
        switch (option) {
            case 1:
                organized = controller.organizeChestByName();
                if (organized) {
                    System.out.println("All chests have been organized by name.");

                }
                break;
                case 2:
                    organized = controller.organizeChestBySeason();
                    if (organized) {
                        System.out.println("All chests have been organized by season.");
                    }
                    break;
                    case 3:
                        organized = controller.organizeChestByGrowthDays();
                        if (organized) {
                            System.out.println("All chests have been organized by growth days.");
                        }
                        break;
                        default:
                            System.out.println("Invalid option. Please try again.");
        }

    }


}
