package exceptions;

public class ChestFullException extends Exception {
    public ChestFullException(String message) {
        super(message);
    }
}
