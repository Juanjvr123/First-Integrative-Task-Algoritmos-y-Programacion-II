package exceptions;

public class InexistentChestException extends Exception {
    public InexistentChestException(String message) {
        super(message);
    }
}
