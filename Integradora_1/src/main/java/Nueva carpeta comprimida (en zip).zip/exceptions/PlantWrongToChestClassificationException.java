package exceptions;

public class PlantWrongToChestClassificationException extends Exception {
    public PlantWrongToChestClassificationException(String message) {
        super(message);
    }
}