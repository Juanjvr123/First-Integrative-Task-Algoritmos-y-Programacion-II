package exceptions;

public class  InexistentPlantationException extends Exception {
    public InexistentPlantationException(String message) {
        super(message);
    }
}
