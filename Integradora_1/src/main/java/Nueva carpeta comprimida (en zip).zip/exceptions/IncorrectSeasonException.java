package exceptions;

public class IncorrectSeasonException extends Exception {
    public IncorrectSeasonException(String message) {
        super(message);
    }
}
