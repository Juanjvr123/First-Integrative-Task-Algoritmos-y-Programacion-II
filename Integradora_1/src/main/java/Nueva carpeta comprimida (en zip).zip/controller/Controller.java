package controller;

import exceptions.*;
import model.Plantation;
import model.Chest;
import model.Season;
import model.Stack;
import structures.LinkedList;
import structures.Node;

import java.io.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

public class Controller {

    private LinkedList<Plantation> plantations;
    private LinkedList<Plantation> inventory;
    private LinkedList<Plantation> cropField;
    private LinkedList<Chest> chests;
    private ScheduledExecutorService scheduler;
    private Season currentSeason;
    private int daysInCurrentSeason;
    private File data;
    private File listJson;

    private final int INVENTORY_LIMIT = 30;
    private int woodCount;
    public Controller() {
        plantations = new LinkedList<>();
        inventory = new LinkedList<>();
        cropField = new LinkedList<>();
        chests = new LinkedList<>();
        currentSeason = Season.SPRING;
        daysInCurrentSeason = 0;
        woodCount = 0;
        startGrowthUpdateScheduler();
        File projectDir = new File(System.getProperty("user.dir"));
        data = new File(projectDir + File.separator + "src" + File.separator + "main" + File.separator + "data");
        listJson = new File(data.getAbsolutePath() + File.separator + "plantations.json");
        createResources();
        loadPlantationsFromJson();
    }

    public void createResources() {
        if (!data.exists()) {
            if (data.mkdir()) {
                System.out.println("Directorio de datos creado en: " + data.getAbsolutePath());
            } else {
                System.out.println("Error al crear el directorio de datos.");
            }
        }
    }

    public void loadPlantationsFromJson() {
        try (FileReader reader = new FileReader(listJson)) {
            System.out.println("Cargando inventario desde: " + listJson.getAbsolutePath());
            Type productListType = new TypeToken<List<Plantation>>() {}.getType();
            List<Plantation> productList = new Gson().fromJson(reader, productListType);

            if (productList == null) {
                System.out.println("El archivo JSON está vacío o mal formateado.");
                return;
            }

            for (Plantation plantation : productList) {
                plantations.add(new Plantation(plantation.getName(), plantation.getSeason()));
                System.out.println("Plantation cargada: " + plantation);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar el inventario: " + e.getMessage());
        }
    }

    public boolean createPlantationByName(String name) throws IncorrectSeasonException {
        Node<Plantation> current = plantations.getHead();

        while (current != null) {
            Plantation plantation = current.getData();
            if (plantation.getName().equalsIgnoreCase(name)) {
                if (canAddPlantation(plantation)) {
                    Plantation copy = new Plantation(plantation.getName(), plantation.getSeason());
                    cropField.add(copy);
                    return true;
                } else {
                    throw new IncorrectSeasonException("Cannot plant " + name + " in the current season: " + currentSeason);
                }
            }
            current = current.getNextNode();
        }

        return false;
    }

    public String showCurrentSeason(){
        return currentSeason.toString();
    }

    private void startGrowthUpdateScheduler() {
        scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::updateGrowthDays, 0, 1, TimeUnit.MINUTES);
    }

    private boolean canAddPlantation(Plantation plantation) {
        if (plantation.getSeason() == Season.OTHER) {
            return true;  // Los cultivos con la estación OTHER se pueden añadir en cualquier momento
        }
        return plantation.getSeason() == currentSeason;  // Coincidir con la estación actual
    }

    private void updateGrowthDays() {
        Node<Plantation> current = cropField.getHead();
        Node<Plantation> prev = null;

        while (current != null) {
            Plantation plantation = current.getData();
            plantation.incrementGrowthDays(28);  // Incrementar los días de crecimiento en 28

            if (plantation.hasExceededSeason() || (plantation.getSeason() != Season.OTHER && plantation.getSeason() != currentSeason)) {
                if (prev == null) {
                    cropField.removeFirst();
                } else {
                    prev.setNextNode(current.getNextNode());  // Eliminar el elemento actual
                }
            } else {
                prev = current;
            }

            current = current.getNextNode();
        }

        updateSeason();  // Actualizar la estación después de cada minuto
        System.out.println(cropField.printList());
    }

    private void updateSeason() {
        daysInCurrentSeason++;
        if (daysInCurrentSeason >= 28) {  // Cada estación dura 28 días
            daysInCurrentSeason = 0;
            currentSeason = getNextSeason();
        }
    }

    private Season getNextSeason() {
        switch (currentSeason) {
            case SPRING:
                return Season.SUMMER;
            case SUMMER:
                return Season.AUTUMN;
            case AUTUMN:
                return Season.WINTER;
            case WINTER:
                return Season.SPRING;
            default:
                return currentSeason;
        }
    }


    public String listAvaliblePlantations() {
        return plantations.printList();
    }

    public String listCropFieldReadyPlantations() {
        return cropField.printList();
    }


    public boolean movePlantationFromCropFieldToInventory(String plantationName) throws InventoryFullException {
        if (inventory.size() >= INVENTORY_LIMIT) {
            throw new InventoryFullException("The inventory is full! Cannot add more plantations.");
        }

        Node<Plantation> current = cropField.getHead();
        Node<Plantation> prev = null;

        while (current != null) {
            Plantation plantation = current.getData();
            if (plantation.getName().equalsIgnoreCase(plantationName)) {
                // Eliminar del cropField
                if (prev == null) {
                    cropField.removeFirst();
                } else {
                    prev.setNextNode(current.getNextNode());
                }

                inventory.add(plantation);
                return true;
            }
            prev = current;
            current = current.getNextNode();
        }

        return false;
    }

    public boolean createChest(String chestName, String classification) {
        if (!checkResourcesForChest()) {
            return false; // No hay suficientes recursos
        }

        Chest newChest = new Chest(chestName);
        if (classification != null) {
            newChest.setClassificationType(classification.toString());
            newChest.setClassified(true); // Marcar como clasificado
        }

        chests.add(newChest);
        return true; // Cofre creado exitosamente
    }



    private boolean checkResourcesForChest() {
        int woodCount = 0;

        Node<Plantation> current = inventory.getHead();
        while (current != null) {
            Plantation item = current.getData();
            if (item.getName().equalsIgnoreCase("Madera")) {
                woodCount += 1;
            }
            current = current.getNextNode();
        }

        if (woodCount >= 50) {

            removeWoodFromInventory(50);
            return true;
        } else {

            return false;
        }
    }

    private void removeWoodFromInventory(int amount) {
        Node<Plantation> current = inventory.getHead();
        int woodRemoved = 0;

        while (current != null && woodRemoved < amount) {
            Plantation item = current.getData();
            if (item.getName().equalsIgnoreCase("Madera")) {
                inventory.remove(current.getData());  // Eliminamos la madera del inventario
                woodRemoved += 1;
            }
            current = current.getNextNode();
        }


    }

    public String listChests() {
        StringBuilder sb = new StringBuilder();
        int count = 1;
        Node<Chest> current = chests.getHead();
        while (current != null) {
            sb.append("Cofre ").append(count).append(": ").append(current.getData().listPlantations()).append("\n");
            current = current.getNextNode();
            count++;
        }
        return sb.toString();
    }

    public boolean movePlantationToChest(Chest chest, Plantation plantation) throws ChestFullException, IncorrectSeasonException {
        if (chest.isFull()) {
            throw new ChestFullException("El cofre está lleno.");
        }

        // Verificar si la planta coincide con la clasificación del cofre
        if (!chest.getClassificationType().equals("All") && !chest.getClassificationType().equals(plantation.getSeason().toString())) {
            throw new IncorrectSeasonException("La planta no coincide con la clasificación del cofre.");
        }

        Node<Stack> current = chest.getStacks().getHead();
        while (current != null) {
            Stack stack = current.getData();
            // Si encontramos un stack de la misma planta que no está lleno, la agregamos a ese stack
            if (stack.getPlantation().getName().equalsIgnoreCase(plantation.getName()) && !stack.isFull())
                return stack.addPlantation(plantation);
            current = current.getNextNode();
        }

        // Si no encontramos un stack adecuado, creamos uno nuevo
        Stack newStack = new Stack(plantation);
        if (chest.getStacks().size() < Chest.MAX_STACKS) {
            chest.getStacks().add(newStack);
            return true;
        } else {
            throw new ChestFullException("El cofre está lleno. No se puede agregar más stacks.");
        }
    }


    public void addWood(int amount) {
        this.woodCount += amount;
        System.out.println(amount + " de madera añadidos al inventario. Total de madera: " + woodCount);
    }

    public boolean organizeChestByName() {
        Node<Chest> currentChest = chests.getHead();
        boolean organized = false;

        while (currentChest != null) {
            currentChest.getData().organizeByName();
            currentChest = currentChest.getNextNode();
            organized = true;
        }

        return organized;
    }


    public boolean organizeChestBySeason() {
        Node<Chest> currentChest = chests.getHead();
        boolean organized = false;

        while (currentChest != null) {
            currentChest.getData().organizeBySeason();
            currentChest = currentChest.getNextNode();
            organized = true;
        }

        return organized;
    }


    public boolean organizeChestByGrowthDays() {
        Node<Chest> currentChest = chests.getHead();
        boolean organized = false;

        while (currentChest != null) {
            currentChest.getData().organizeByGrowthDays();
            currentChest = currentChest.getNextNode();
            organized = true;
        }

        return organized;
    }


    public void classifyChest(Chest chestName, Season season) throws InexistentChestException {
        Node<Chest> currentChest = chests.getHead();
        while (currentChest != null) {
            Chest chest = currentChest.getData();
            if (chest.getClassificationType().equalsIgnoreCase(String.valueOf(chestName))) {
                chest.setClassificationType(season.toString());
                System.out.println("El cofre ha sido clasificado para almacenar solo items de tipo: " + season.toString());
                return;
            }
            currentChest = currentChest.getNextNode();
        }
        throw new InexistentChestException("Cofre no encontrado.");
    }




    public Chest searchChestByName(String chestName) {
        Node<Chest> currentChest = chests.getHead();

        while (currentChest != null) {
            Chest chest = currentChest.getData();
            if (chest.getClassificationType().equalsIgnoreCase(chestName)) {
                return chest;
            }
            currentChest = currentChest.getNextNode();
        }

        return null;
    }

    public String listChestPlantations(Chest chest){
        if (chest != null) {
           return chest.listPlantations();
        }
        return null;
    }

    public boolean validateOrganizedChest(Chest chest) {
        // Implementa la lógica para validar si el cofre está organizado y clasificado
        return chest.isClassified(); // Retorna true si el cofre está clasificado
    }

    public String listChestPlantationsByPartialName(Chest chest, String partialName) {
        StringBuilder sb = new StringBuilder();
        for (Stack stack : chest.getStacks()) {
            for (Plantation plantation : stack.getPlantations()) {
                if (plantation.getName().toLowerCase().startsWith(partialName.toLowerCase())) {
                    sb.append(plantation.getName()).append("\n");
                }
            }
        }
        return sb.toString();
    }

    public void moveItemFromChestToInventory(Chest chest, String plantationName)
            throws InventoryFullException, PlantWrongToChestClassificationException, PlantWrongToChestClassificationException, InexistentPlantationException {

        Stack targetStack = null;
        Plantation plantationToMove = null;

        // Buscar el stack que contiene la plantación deseada
        for (Stack stack : chest.getStacks()) {
            for (Plantation plantation : stack.getPlantations()) {
                if (plantation.getName().equalsIgnoreCase(plantationName)) {
                    targetStack = stack;
                    plantationToMove = plantation;
                    break;
                }
            }
            if (plantationToMove != null) break;
        }

        if (plantationToMove == null) {
            throw new InexistentPlantationException("Plantation not found in the chest.");
        }

        // Verifica la clasificación del cofre y la plantación
        if (!chest.getClassificationType().equalsIgnoreCase("All") &&
                !chest.getClassificationType().equalsIgnoreCase(plantationToMove.getSeason().toString())) {
            throw new PlantWrongToChestClassificationException("The plantation season does not match the chest classification.");
        }

        // Verifica si el inventario está lleno
        if (inventory.size() >= 30) {
            throw new InventoryFullException("Inventory is full.");
        }

        // Mueve solo una planta del stack al inventario
        inventory.add(plantationToMove);
        targetStack.removePlantation(plantationToMove); // Remueve una instancia del stack

        System.out.println("Plantation moved successfully.");
    }

    public String listInventory() {
        return inventory.printList();  // Asegúrate de que inventory es la lista donde guardas las plantaciones.
    }

    public Plantation getPlantationFromInventory(String plantationName) throws InexistentPlantationException {
        for (Plantation plantation : inventory.getPlantations()) {
            if (plantation.getName().equalsIgnoreCase(plantationName)) {
                return plantation;
            }
        }
        throw new InexistentPlantationException("Plantation not found in the inventory.");
    }


}